A Pen created at CodePen.io. You can find this one at https://codepen.io/enricotoniato/pen/gbzJYO.

 PIXI experiment 404 not found particle text by Enrico Toniato http://enricotoniato.com