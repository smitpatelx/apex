A Pen created at CodePen.io. You can find this one at https://codepen.io/nw/pen/WQmxYY.

 Fargo-inspired 404 page for DailyUI #008

Snow loosely based on http://codepen.io/loktar00/pen/CHpGo and http://php.quicoto.com/snow-html-canvas/