A Pen created at CodePen.io. You can find this one at https://codepen.io/saransh/pen/aezht.

 Simple animated 404 page for a startup I'm working with.